## Todo application

This project is my first MERN stack application.
This project is simple TODO application 

Following are the feature this application gives:-

-User can add things to their todo.
-User can see their existing Todos.
-User can mark their done Todo.